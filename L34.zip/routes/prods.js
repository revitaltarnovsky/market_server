const express = require('express');
const router = express.Router();
const {prodsModel,validProd} = require("../models/prods_model")

/* GET home page. */
router.get('/', (req, res, next) => {
  prodsModel.find({})
  .then(data => {
    res.json(data)

  })
});

router.post("/add",async(req,res) => {
  let dataBody = req.body;
  let prod = await validProd(dataBody);
  if(prod.error){
    res.status(400).json(prod.error.details[0])
  }
  else{
    try{
      let saveData = await prodsModel.insertMany([req.body]);
      res.json(saveData[0])
      
    }
    catch{
      res.status(400).json({ message: "error insert new prod, already in data" })
    }
  }
})

router.post("/update",async(req,res) => {
  let dataBody = req.body;
  let prod = await validProd(dataBody);
  if(prod.error){
    res.status(400).json(prod.error.details[0])
  }
  else{
    try{
      // באפדייט צריך למצוא איי די קודם , חוץ מזה די דומה להוספה
      let updateData = await prodsModel.updateOne({_id:req.body.id},req.body);
      res.json(updateData)
      
    }
    catch{
      res.status(400).json({ message: "error cant find id" })
    }
  }
})

router.post("/del",(req,res) => {
  let delId = req.body.del
  /// מחפש את מי למחוק לפי איי די שנשלח לו
  prodsModel.deleteOne({_id:delId})
  .then(data => {
    if(data.deletedCount > 0 ){
      res.json({message:"deleted"});
    }
    else{
      res.status(400).json({error:"error id not found"});
    }
  })
})

router.get("/cat/:catId",(req,res) => {
  let catId = req.params.catId;
  prodsModel.find({cat:catId})
  .then(data => {
    res.json(data);
  })
  .catch(err => {
    res.status(400).json(err)
  })
})

router.get("/search/",(req,res) => {
// מה שבא אחרי הסימן שאלה נקרא
// QUERY STRING and we collect it with req.query....
  //http://localhost:3000/prods/search/?q=Mil
  // משתמשים בריגולר מכיוון שאנחנו רוצים לעשות חיפוש
  // לחלק מהסטינג ושלא יהיה מדוייק
  const mySearch = new RegExp(`${req.query.q}`);
  //const mySearch = req.query.q;
  // prodsModel.find({name:mySearch})
  // $or = קווירי מיוחד של המונגו לחיפוש בכמה עמודות
  prodsModel.find({$or:[{name:mySearch},{cat:mySearch}]})
  .then(data => {
    res.json(data)
  })
})


router.get("/price",(req,res) => {
  //gte == greate equal >=
  //http://localhost:3000/prods/price/?min=10
  prodsModel.find({price:{$gte:req.query.min}})
  .then(data => {
    res.json(data);
  })
})

module.exports = router;
